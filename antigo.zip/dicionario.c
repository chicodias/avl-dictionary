/* 
 * File:   dicionario.c
 * Author: Francisco Rosa Dias de Miranda e Hiago Vinicius Americo
 */
#include "avl.h"

/* Insere um elemento no dicionario*/
bool dicionario_inserir (AVL *T, ITEM item)
{
    return TRUE;
}

/* Remove um elemento do dicionário  */
bool dicionario_remover (AVL *T, ITEM item)
{
    return FALSE;
}
