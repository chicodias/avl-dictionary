#include <stdio.h>
#include <string.h>
#include "avl.h"

int main(){

// criacao da arv
    AVL * dic = avl_criar();

    char mov[TAM_MAX];
// insercao
    while (1)
    {
        // lê um filme da entrada padrão
        scanf("%s ", mov);
        // caractere que indica fim do buffer                    
        if (strcmp(mov, "#") != 0)
        {
            printf("%d\n",avl_inserir(dic, mov));
            printf("bus%s\n",avl_buscar(dic, mov));
            avl_imprimir(dic);
        }
        else break;
    }
    


// busca

// remocao



    return 0;
}